Include four (04) individual reports and One (01) group report

